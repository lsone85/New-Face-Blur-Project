from ui_qt import run_ui

if __name__ == "__main__":
    run_ui()