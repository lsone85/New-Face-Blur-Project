import sys
import os
from PyQt5.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel, QFileDialog,
    QListWidget, QProgressBar, QTextEdit, QInputDialog, QMessageBox
)
from PyQt5.QtGui import QPixmap
from PyQt5.QtCore import Qt, QThread, pyqtSignal
from face_processing import process_video, add_to_whitelist, crop_face, WHITELIST_DIR

OUTPUT_DIR = "output"

class VideoProcessorThread(QThread):
    progress_signal = pyqtSignal(int)
    log_signal = pyqtSignal(str)
    finished_signal = pyqtSignal(bool)

    def __init__(self, input_path, output_path):
        super().__init__()
        self.input_path = input_path
        self.output_path = output_path

    def run(self):
        def progress_callback(percent):
            self.progress_signal.emit(percent)
        def log_callback(msg):
            self.log_signal.emit(msg)
        result = process_video(self.input_path, self.output_path, progress_callback, log_callback)
        self.finished_signal.emit(result)

class FaceBlurApp(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Face Blur App (PyQt5)")
        self.setGeometry(100, 100, 650, 480)
        os.makedirs(WHITELIST_DIR, exist_ok=True)
        os.makedirs(OUTPUT_DIR, exist_ok=True)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()

        # Video selection and processing
        video_layout = QHBoxLayout()
        self.video_label = QLabel("No video selected.")
        self.btn_select_video = QPushButton("Select Video")
        self.btn_select_video.clicked.connect(self.select_video)
        self.btn_process_video = QPushButton("Process & Export")
        self.btn_process_video.clicked.connect(self.process_video)
        self.btn_process_video.setEnabled(False)
        video_layout.addWidget(self.video_label)
        video_layout.addWidget(self.btn_select_video)
        video_layout.addWidget(self.btn_process_video)
        layout.addLayout(video_layout)

        # Progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setValue(0)
        layout.addWidget(self.progress_bar)

        # Log output
        self.log_output = QTextEdit()
        self.log_output.setReadOnly(True)
        layout.addWidget(self.log_output)

        # Whitelist management
        wl_layout = QHBoxLayout()
        self.wl_list = QListWidget()
        self.refresh_whitelist()
        wl_layout.addWidget(self.wl_list)
        wl_btn_layout = QVBoxLayout()
        self.btn_add_face = QPushButton("Add Face (crop)")
        self.btn_add_face.clicked.connect(self.add_face)
        self.btn_remove_face = QPushButton("Remove Selected")
        self.btn_remove_face.clicked.connect(self.remove_face)
        wl_btn_layout.addWidget(self.btn_add_face)
        wl_btn_layout.addWidget(self.btn_remove_face)
        wl_layout.addLayout(wl_btn_layout)
        layout.addLayout(wl_layout)

        # Face preview
        self.face_preview = QLabel()
        self.face_preview.setFixedSize(128, 128)
        layout.addWidget(self.face_preview, alignment=Qt.AlignCenter)
        self.wl_list.currentItemChanged.connect(self.show_face_preview)

        self.setLayout(layout)
        self.selected_video = None

    def select_video(self):
        fname, _ = QFileDialog.getOpenFileName(self, "Select Video", "", "Video Files (*.mp4 *.avi)")
        if fname:
            self.selected_video = fname
            self.video_label.setText(os.path.basename(fname))
            self.btn_process_video.setEnabled(True)

    def process_video(self):
        if not self.selected_video:
            QMessageBox.warning(self, "Error", "No video selected.")
            return
        out_fname, _ = QFileDialog.getSaveFileName(self, "Save Output", OUTPUT_DIR, "AVI Files (*.avi)")
        if not out_fname:
            return
        self.progress_bar.setValue(0)
        self.log_output.clear()
        self.btn_process_video.setEnabled(False)
        self.thread = VideoProcessorThread(self.selected_video, out_fname)
        self.thread.progress_signal.connect(self.progress_bar.setValue)
        self.thread.log_signal.connect(self.log_output.append)
        self.thread.finished_signal.connect(self.on_processing_done)
        self.thread.start()

    def on_processing_done(self, success):
        self.btn_process_video.setEnabled(True)
        if success:
            QMessageBox.information(self, "Done", "Video exported successfully.")
        else:
            QMessageBox.critical(self, "Error", "Processing failed.")

    def add_face(self):
        fname, _ = QFileDialog.getOpenFileName(self, "Select Face Image", "", "Image Files (*.jpg *.jpeg *.png)")
        if not fname:
            return
        cropped_img = crop_face(fname)
        if cropped_img is None:
            QMessageBox.warning(self, "Error", "Could not detect a face. Try another image.")
            return
        add_to_whitelist(fname, cropped_img)
        self.refresh_whitelist()

    def refresh_whitelist(self):
        self.wl_list.clear()
        for img_file in os.listdir(WHITELIST_DIR):
            self.wl_list.addItem(img_file)

    def remove_face(self):
        selected = self.wl_list.currentItem()
        if selected:
            img_file = selected.text()
            os.remove(os.path.join(WHITELIST_DIR, img_file))
            self.refresh_whitelist()
            self.face_preview.clear()

    def show_face_preview(self):
        selected = self.wl_list.currentItem()
        if selected:
            img_file = selected.text()
            img_path = os.path.join(WHITELIST_DIR, img_file)
            pixmap = QPixmap(img_path)
            pixmap = pixmap.scaled(self.face_preview.width(), self.face_preview.height(), Qt.KeepAspectRatio)
            self.face_preview.setPixmap(pixmap)
        else:
            self.face_preview.clear()

def run_ui():
    app = QApplication(sys.argv)
    window = FaceBlurApp()
    window.show()
    sys.exit(app.exec_())